<?php
// created: 2013-03-03 13:03:23
$dictionary["Opportunity"]["fields"]["part_participants_opportunities"] = array (
  'name' => 'part_participants_opportunities',
  'type' => 'link',
  'relationship' => 'part_participants_opportunities',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_PART_PARTICIPANTS_OPPORTUNITIES_FROM_PART_PARTICIPANTS_TITLE',
);
