{
	"properties": [

	{

		"title":"Общая сумма: $10 тыс."
,
		"subtitle":"Размеры сделок в $1 тыс."
,
		"type":"horizontal bar chart"
,
		"legend":"on"
,
		"labels":"value"
,
		"thousands":""

	}

	],

	"label": [

		"Анализ потребностей"
,
		"Ком. предложение /Выставление счёта"

	],

	"color": [

		"#8c2b2b"
,
		"#468c2b"
,
		"#2b5d8c"
,
		"#cd5200"
,
		"#e6bf00"
,
		"#7f3acd"
,
		"#00a9b8"
,
		"#572323"
,
		"#004d00"
,
		"#000087"
,
		"#e48d30"
,
		"#9fba09"
,
		"#560066"
,
		"#009f92"
,
		"#b36262"
,
		"#38795c"
,
		"#3D3D99"
,
		"#99623d"
,
		"#998a3d"
,
		"#994e78"
,
		"#3d6899"
,
		"#CC0000"
,
		"#00CC00"
,
		"#0000CC"
,
		"#cc5200"
,
		"#ccaa00"
,
		"#6600cc"
,
		"#005fcc"

	],

	"values": [

	{

		"label": [

			"Анализ потребностей"

		],

		"values": [

			4.8

		],

		"valuelabels": [

			"$4.80 тыс."

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26assigned_user_id%5B%5D%3D84576838-73e2-3ede-557e-509cd29a92e5%26date_closed_advanced_range_choice%3Dbetween%26start_range_date_closed_advanced%3D01%252F14%252F2013%26end_range_date_closed_advanced%3D07%252F14%252F2013%26sales_stage_advanced%5B%5D%3DNeeds%2BAnalysis"

		]

	}
,
	{

		"label": [

			"Ком. предложение /Выставление счёта"

		],

		"values": [

			5

		],

		"valuelabels": [

			"$5.00 тыс."

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26assigned_user_id%5B%5D%3D84576838-73e2-3ede-557e-509cd29a92e5%26date_closed_advanced_range_choice%3Dbetween%26start_range_date_closed_advanced%3D01%252F14%252F2013%26end_range_date_closed_advanced%3D07%252F14%252F2013%26sales_stage_advanced%5B%5D%3DProposal%252FPrice%2BQuote"

		]

	}

	]

}