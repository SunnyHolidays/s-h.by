{
	"properties": [

	{

		"title":""
,
		"subtitle":"Размеры сделок в $1 тыс."
,
		"type":"pie chart"
,
		"legend":"on"
,
		"labels":"value"
,
		"thousands":""

	}

	],

	"label": [

		""
,
		"Существующий клиент"
,
		"Собственный"
,
		"Веб-сайт"
,
		"Разговор"
,
		"Другое"

	],

	"color": [

		"#8c2b2b"
,
		"#468c2b"
,
		"#2b5d8c"
,
		"#cd5200"
,
		"#e6bf00"
,
		"#7f3acd"
,
		"#00a9b8"
,
		"#572323"
,
		"#004d00"
,
		"#000087"
,
		"#e48d30"
,
		"#9fba09"
,
		"#560066"
,
		"#009f92"
,
		"#b36262"
,
		"#38795c"
,
		"#3D3D99"
,
		"#99623d"
,
		"#998a3d"
,
		"#994e78"
,
		"#3d6899"
,
		"#CC0000"
,
		"#00CC00"
,
		"#0000CC"
,
		"#cc5200"
,
		"#ccaa00"
,
		"#6600cc"
,
		"#005fcc"

	],

	"values": [

	{

		"label": [

			""

		],

		"values": [

			16.384

		],

		"valuelabels": [

			"$16.38K"

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26lead_source%3D"

		]

	}
,
	{

		"label": [

			"Существующий клиент"

		],

		"values": [

			2

		],

		"valuelabels": [

			"$2.00K"

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26lead_source%3DExisting%2BCustomer"

		]

	}
,
	{

		"label": [

			"Собственный"

		],

		"values": [

			11.19

		],

		"valuelabels": [

			"$11.19K"

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26lead_source%3DSelf%2BGenerated"

		]

	}
,
	{

		"label": [

			"Веб-сайт"

		],

		"values": [

			165.607

		],

		"valuelabels": [

			"$165.61K"

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26lead_source%3DWeb%2BSite"

		]

	}
,
	{

		"label": [

			"Разговор"

		],

		"values": [

			8.395

		],

		"valuelabels": [

			"$8.40K"

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26lead_source%3DWord%2Bof%2Bmouth"

		]

	}
,
	{

		"label": [

			"Другое"

		],

		"values": [

			10.205

		],

		"valuelabels": [

			"$10.21K"

		],

		"links": [

			"index.php%3Fmodule%3DOpportunities%26action%3Dindex%26query%3Dtrue%26searchFormTab%3Dadvanced_search%26lead_source%3DOther"

		]

	}

	
]

}