<?php
$module_name = 'part_participants';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_contact_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'snamerus',
            'label' => 'LBL_SNAMERUS',
          ),
          1 => 
          array (
            'name' => 'last_name',
            'comment' => 'Last name of the contact',
            'label' => 'LBL_LAST_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fnamerus',
            'label' => 'LBL_FNAMERUS',
          ),
          1 => 
          array (
            'name' => 'first_name',
            'comment' => 'First name of the contact',
            'label' => 'LBL_FIRST_NAME',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'mnamerus',
            'label' => 'LBL_MNAMERUS',
          ),
          1 => 
          array (
            'name' => 'birthday',
            'label' => 'LBL_BIRTHDAY',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'passport_num',
            'label' => 'LBL_PASSPORT_NUM',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'passport_who',
            'label' => 'LBL_PASSPORT_WHO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'passport_date',
            'label' => 'LBL_PASSPORT_DATE',
          ),
          1 => 
          array (
            'name' => 'passport_valid',
            'label' => 'LBL_PASSPORT_VALID',
          ),
        ),
      ),
    ),
  ),
);
?>
