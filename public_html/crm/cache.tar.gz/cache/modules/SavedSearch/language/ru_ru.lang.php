<?php
// created: 2013-03-11 13:54:00
$mod_strings = array (
  'LBL_MODULE_TITLE' => 'Мои сохраненные условия поиска',
  'LBL_SEARCH_FORM_TITLE' => 'Мои сохраненные условия поиска : Поиск',
  'LBL_LIST_FORM_TITLE' => 'Список условий поиска',
  'LBL_DELETE_CONFIRM' => 'Вы действительно хотите удалить выбранное условие поиска?',
  'LBL_UPDATE_BUTTON_TITLE' => 'Обновить эти условия поиска',
  'LBL_DELETE_BUTTON_TITLE' => 'Удалить эти условия поиска',
  'LBL_SAVE_BUTTON_TITLE' => 'Сохранить текущие условия поиска',
  'LBL_LIST_NAME' => 'Имя',
  'LBL_LIST_MODULE' => 'Модуль',
  'LBL_ORDER_BY_COLUMNS' => 'Сортировать по колонке:',
  'LBL_DIRECTION' => 'Сортировка:',
  'LBL_SAVE_SEARCH_AS' => 'Сохранить условия поиска:',
  'LBL_SAVE_SEARCH_AS_HELP' => 'Сохраняет условия поиска, включая фильтры на закладке расширенного поиска.',
  'LBL_PREVIOUS_SAVED_SEARCH' => 'Условия поиска:',
  'LBL_PREVIOUS_SAVED_SEARCH_HELP' => 'Удаление или редактирование существующих условий поиска.',
  'LBL_ASCENDING' => 'Восходящая',
  'LBL_DESCENDING' => 'Нисходящая',
  'LBL_MODIFY_CURRENT_SEARCH' => 'Условие поиска',
);