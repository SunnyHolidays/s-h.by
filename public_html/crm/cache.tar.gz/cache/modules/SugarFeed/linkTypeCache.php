<?php

$linkTypeList = array (
  'YouTube' => 'YouTube',
  'Link' => 'Link',
  'Image' => 'Image',
);