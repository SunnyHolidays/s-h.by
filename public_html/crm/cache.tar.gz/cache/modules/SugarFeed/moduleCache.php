<?php

$feedModules = array (
  'UserFeed' => 'UserFeed',
  'Opportunities' => 'Opportunities',
  'Contacts' => 'Contacts',
  'Cases' => 'Cases',
  'Leads' => 'Leads',
);