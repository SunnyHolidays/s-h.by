<?php
// created: 2013-03-13 12:45:26
$mod_strings = array (
  'LBL_ALLOW_ALL' => 'Все',
  'LBL_ALLOW_NONE' => 'Нет',
  'LBL_ALLOW_OWNER' => 'Владелец',
  'LBL_ROLE' => 'Роль',
  'LBL_NAME' => 'Имя',
  'LBL_DESCRIPTION' => 'Описание',
  'LIST_ROLES' => 'Роли',
  'LBL_USERS_SUBPANEL_TITLE' => 'Пользователи',
  'LIST_ROLES_BY_USER' => 'Список ролей по пользователям',
  'LBL_ROLES_SUBPANEL_TITLE' => 'Роли пользователя',
  'LBL_SEARCH_FORM_TITLE' => 'Найти',
  'LBL_NO_ACCESS' => 'У Вас нет доступа к данной странице. Свяжитесь с вашим системным администратором для получения соответствующих прав.',
  'LBL_REDIRECT_TO_HOME' => 'Перенаправление на ГЛАВНУЮ страницу через',
  'LBL_SECONDS' => 'секунд',
  'LBL_ADDING' => 'Добавлено для ',
);