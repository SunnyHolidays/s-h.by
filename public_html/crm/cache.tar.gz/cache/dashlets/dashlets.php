<?php
// created: 2013-03-11 13:54:26
$dashletsFiles = array (
  'SugarFeedDashlet' => 
  array (
    'file' => 'modules/SugarFeed/Dashlets/SugarFeedDashlet/SugarFeedDashlet.php',
    'class' => 'SugarFeedDashlet',
    'meta' => 'modules/SugarFeed/Dashlets/SugarFeedDashlet/SugarFeedDashlet.meta.php',
    'module' => 'SugarFeed',
  ),
  'MyClosedOpportunitiesDashlet' => 
  array (
    'file' => 'modules/Opportunities/Dashlets/MyClosedOpportunitiesDashlet/MyClosedOpportunitiesDashlet.php',
    'class' => 'MyClosedOpportunitiesDashlet',
    'meta' => 'modules/Opportunities/Dashlets/MyClosedOpportunitiesDashlet/MyClosedOpportunitiesDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'MyOpportunitiesDashlet' => 
  array (
    'file' => 'modules/Opportunities/Dashlets/MyOpportunitiesDashlet/MyOpportunitiesDashlet.php',
    'class' => 'MyOpportunitiesDashlet',
    'meta' => 'modules/Opportunities/Dashlets/MyOpportunitiesDashlet/MyOpportunitiesDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'MyContactsDashlet' => 
  array (
    'file' => 'modules/Contacts/Dashlets/MyContactsDashlet/MyContactsDashlet.php',
    'class' => 'MyContactsDashlet',
    'meta' => 'modules/Contacts/Dashlets/MyContactsDashlet/MyContactsDashlet.meta.php',
    'module' => 'Contacts',
  ),
  'MyBugsDashlet' => 
  array (
    'file' => 'modules/Bugs/Dashlets/MyBugsDashlet/MyBugsDashlet.php',
    'class' => 'MyBugsDashlet',
    'meta' => 'modules/Bugs/Dashlets/MyBugsDashlet/MyBugsDashlet.meta.php',
    'module' => 'Bugs',
  ),
  'MyDocumentsDashlet' => 
  array (
    'file' => 'modules/Documents/Dashlets/MyDocumentsDashlet/MyDocumentsDashlet.php',
    'class' => 'MyDocumentsDashlet',
    'meta' => 'modules/Documents/Dashlets/MyDocumentsDashlet/MyDocumentsDashlet.meta.php',
    'module' => 'Documents',
  ),
  'MyLeadsDashlet' => 
  array (
    'file' => 'modules/Leads/Dashlets/MyLeadsDashlet/MyLeadsDashlet.php',
    'class' => 'MyLeadsDashlet',
    'meta' => 'modules/Leads/Dashlets/MyLeadsDashlet/MyLeadsDashlet.meta.php',
    'module' => 'Leads',
  ),
  'MyNotesDashlet' => 
  array (
    'file' => 'modules/Notes/Dashlets/MyNotesDashlet/MyNotesDashlet.php',
    'class' => 'MyNotesDashlet',
    'meta' => 'modules/Notes/Dashlets/MyNotesDashlet/MyNotesDashlet.meta.php',
    'module' => 'Notes',
  ),
  'TopCampaignsDashlet' => 
  array (
    'file' => 'modules/Campaigns/Dashlets/TopCampaignsDashlet/TopCampaignsDashlet.php',
    'class' => 'TopCampaignsDashlet',
    'meta' => 'modules/Campaigns/Dashlets/TopCampaignsDashlet/TopCampaignsDashlet.meta.php',
    'module' => 'Campaigns',
  ),
  'MyCallsDashlet' => 
  array (
    'file' => 'modules/Calls/Dashlets/MyCallsDashlet/MyCallsDashlet.php',
    'class' => 'MyCallsDashlet',
    'meta' => 'modules/Calls/Dashlets/MyCallsDashlet/MyCallsDashlet.meta.php',
    'module' => 'Calls',
  ),
  'MyPipelineBySalesStageDashlet' => 
  array (
    'file' => 'modules/Charts/Dashlets/MyPipelineBySalesStageDashlet/MyPipelineBySalesStageDashlet.php',
    'class' => 'MyPipelineBySalesStageDashlet',
    'meta' => 'modules/Charts/Dashlets/MyPipelineBySalesStageDashlet/MyPipelineBySalesStageDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'OutcomeByMonthDashlet' => 
  array (
    'file' => 'modules/Charts/Dashlets/OutcomeByMonthDashlet/OutcomeByMonthDashlet.php',
    'class' => 'OutcomeByMonthDashlet',
    'meta' => 'modules/Charts/Dashlets/OutcomeByMonthDashlet/OutcomeByMonthDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'OpportunitiesByLeadSourceByOutcomeDashlet' => 
  array (
    'file' => 'modules/Charts/Dashlets/OpportunitiesByLeadSourceByOutcomeDashlet/OpportunitiesByLeadSourceByOutcomeDashlet.php',
    'class' => 'OpportunitiesByLeadSourceByOutcomeDashlet',
    'meta' => 'modules/Charts/Dashlets/OpportunitiesByLeadSourceByOutcomeDashlet/OpportunitiesByLeadSourceByOutcomeDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'CampaignROIChartDashlet' => 
  array (
    'file' => 'modules/Charts/Dashlets/CampaignROIChartDashlet/CampaignROIChartDashlet.php',
    'class' => 'CampaignROIChartDashlet',
    'meta' => 'modules/Charts/Dashlets/CampaignROIChartDashlet/CampaignROIChartDashlet.meta.php',
    'module' => 'Campaigns',
  ),
  'OpportunitiesByLeadSourceDashlet' => 
  array (
    'file' => 'modules/Charts/Dashlets/OpportunitiesByLeadSourceDashlet/OpportunitiesByLeadSourceDashlet.php',
    'class' => 'OpportunitiesByLeadSourceDashlet',
    'meta' => 'modules/Charts/Dashlets/OpportunitiesByLeadSourceDashlet/OpportunitiesByLeadSourceDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'PipelineBySalesStageDashlet' => 
  array (
    'file' => 'modules/Charts/Dashlets/PipelineBySalesStageDashlet/PipelineBySalesStageDashlet.php',
    'class' => 'PipelineBySalesStageDashlet',
    'meta' => 'modules/Charts/Dashlets/PipelineBySalesStageDashlet/PipelineBySalesStageDashlet.meta.php',
    'module' => 'Opportunities',
  ),
  'MyEmailsDashlet' => 
  array (
    'file' => 'modules/Emails/Dashlets/MyEmailsDashlet/MyEmailsDashlet.php',
    'class' => 'MyEmailsDashlet',
    'meta' => 'modules/Emails/Dashlets/MyEmailsDashlet/MyEmailsDashlet.meta.php',
    'module' => 'Emails',
  ),
  'MyMeetingsDashlet' => 
  array (
    'file' => 'modules/Meetings/Dashlets/MyMeetingsDashlet/MyMeetingsDashlet.php',
    'class' => 'MyMeetingsDashlet',
    'meta' => 'modules/Meetings/Dashlets/MyMeetingsDashlet/MyMeetingsDashlet.meta.php',
    'module' => 'Meetings',
  ),
  'MyCasesDashlet' => 
  array (
    'file' => 'modules/Cases/Dashlets/MyCasesDashlet/MyCasesDashlet.php',
    'class' => 'MyCasesDashlet',
    'meta' => 'modules/Cases/Dashlets/MyCasesDashlet/MyCasesDashlet.meta.php',
    'module' => 'Cases',
  ),
  'iFrameDashlet' => 
  array (
    'file' => 'modules/Home/Dashlets/iFrameDashlet/iFrameDashlet.php',
    'class' => 'iFrameDashlet',
    'meta' => 'modules/Home/Dashlets/iFrameDashlet/iFrameDashlet.meta.php',
    'module' => 'Home',
  ),
  'JotPadDashlet' => 
  array (
    'file' => 'modules/Home/Dashlets/JotPadDashlet/JotPadDashlet.php',
    'class' => 'JotPadDashlet',
    'meta' => 'modules/Home/Dashlets/JotPadDashlet/JotPadDashlet.meta.php',
  ),
  'InvadersDashlet' => 
  array (
    'file' => 'modules/Home/Dashlets/InvadersDashlet/InvadersDashlet.php',
    'class' => 'InvadersDashlet',
    'meta' => 'modules/Home/Dashlets/InvadersDashlet/InvadersDashlet.meta.php',
    'icon' => 'modules/Home/Dashlets/InvadersDashlet/InvadersDashlet.icon.jpg',
  ),
  'SugarNewsDashlet' => 
  array (
    'file' => 'modules/Home/Dashlets/SugarNewsDashlet/SugarNewsDashlet.php',
    'class' => 'SugarNewsDashlet',
    'meta' => 'modules/Home/Dashlets/SugarNewsDashlet/SugarNewsDashlet.meta.php',
    'module' => 'Home',
  ),
  'RSSDashlet' => 
  array (
    'file' => 'modules/Home/Dashlets/RSSDashlet/RSSDashlet.php',
    'class' => 'RSSDashlet',
    'meta' => 'modules/Home/Dashlets/RSSDashlet/RSSDashlet.meta.php',
    'icon' => 'modules/Home/Dashlets/RSSDashlet/RSSDashlet.icon.jpg',
  ),
  'ChartsDashlet' => 
  array (
    'file' => 'modules/Home/Dashlets/ChartsDashlet/ChartsDashlet.php',
    'class' => 'ChartsDashlet',
    'meta' => 'modules/Home/Dashlets/ChartsDashlet/ChartsDashlet.meta.php',
  ),
  'MyAccountsDashlet' => 
  array (
    'file' => 'modules/Accounts/Dashlets/MyAccountsDashlet/MyAccountsDashlet.php',
    'class' => 'MyAccountsDashlet',
    'meta' => 'modules/Accounts/Dashlets/MyAccountsDashlet/MyAccountsDashlet.meta.php',
    'module' => 'Accounts',
  ),
  'MyTasksDashlet' => 
  array (
    'file' => 'modules/Tasks/Dashlets/MyTasksDashlet/MyTasksDashlet.php',
    'class' => 'MyTasksDashlet',
    'meta' => 'modules/Tasks/Dashlets/MyTasksDashlet/MyTasksDashlet.meta.php',
    'module' => 'Tasks',
  ),
  'part_participantsDashlet' => 
  array (
    'file' => 'modules/part_participants/Dashlets/part_participantsDashlet/part_participantsDashlet.php',
    'class' => 'part_participantsDashlet',
    'meta' => 'modules/part_participants/Dashlets/part_participantsDashlet/part_participantsDashlet.meta.php',
    'module' => 'part_participants',
  ),
  'CalendarDashlet' => 
  array (
    'file' => 'modules/Calendar/Dashlets/CalendarDashlet/CalendarDashlet.php',
    'class' => 'CalendarDashlet',
    'meta' => 'modules/Calendar/Dashlets/CalendarDashlet/CalendarDashlet.meta.php',
  ),
  'MyProjectTaskDashlet' => 
  array (
    'file' => 'modules/ProjectTask/Dashlets/MyProjectTaskDashlet/MyProjectTaskDashlet.php',
    'class' => 'MyProjectTaskDashlet',
    'meta' => 'modules/ProjectTask/Dashlets/MyProjectTaskDashlet/MyProjectTaskDashlet.meta.php',
    'module' => 'ProjectTask',
  ),
  'MyLateOpportunitiesDashlet' => 
  array (
    'file' => 'custom/modules/Opportunities/Dashlets/MyLateOpportunitiesDashlet/MyLateOpportunitiesDashlet.php',
    'class' => 'MyLateOpportunitiesDashlet',
    'meta' => 'custom/modules/Opportunities/Dashlets/MyLateOpportunitiesDashlet/MyLateOpportunitiesDashlet.meta.php',
    'module' => 'Opportunities',
  ),
);