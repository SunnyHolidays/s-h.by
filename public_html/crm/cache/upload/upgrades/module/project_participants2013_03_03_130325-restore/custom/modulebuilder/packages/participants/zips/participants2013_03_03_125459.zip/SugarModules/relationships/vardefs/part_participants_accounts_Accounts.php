<?php
// created: 2013-03-03 12:54:59
$dictionary["Account"]["fields"]["part_participants_accounts"] = array (
  'name' => 'part_participants_accounts',
  'type' => 'link',
  'relationship' => 'part_participants_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_PART_PARTICIPANTS_ACCOUNTS_FROM_PART_PARTICIPANTS_TITLE',
);
