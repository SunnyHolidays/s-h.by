<?php
/* @var $this HotelsController */
/* @var $model Hotels */

$this->header = 'Добавить отель';

$this->renderPartial('_form', array('model' => $model)); ?>